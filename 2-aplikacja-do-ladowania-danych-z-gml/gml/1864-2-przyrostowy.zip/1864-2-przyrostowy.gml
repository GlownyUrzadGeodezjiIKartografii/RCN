<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection gml:id="obiekty"
xmlns="http://www.w3.org/2001/XMLSchema"
xmlns:xlink="http://www.w3.org/1999/xlink"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:rcw="urn:gugik:specyfikacje:gmlas:rejestrcennieruchomosci:1.0"
xsi:schemaLocation="urn:gugik:specyfikacje:gmlas:rejestrcennieruchomosci:1.0 rcn_1.4.xsd">
<!--Eksporter: RCiWN wersja 4.20  Czas eksportu: 2026-02-26T12:14:32 -->
<gml:featureMember>
<rcw:RCN_Transakcja gml:id="RCN_T_6820">
<rcw:IdRCN>
<rcw:RCN_IdentyfikatorIIP>
<rcw:przestrzenNazw>PL.PZGiK.209</rcw:przestrzenNazw>
<rcw:lokalnyId>25ABB427-CE54-4005-A598-9B86C437161C</rcw:lokalnyId>
</rcw:RCN_IdentyfikatorIIP>
</rcw:IdRCN>
<rcw:oznaczenieTransakcji>RCN_T_6820</rcw:oznaczenieTransakcji>
<rcw:rodzajTransakcji>1</rcw:rodzajTransakcji>
<rcw:stronaSprzedajaca>3</rcw:stronaSprzedajaca>
<rcw:stronaKupujaca>3</rcw:stronaKupujaca>
<rcw:cenaTransakcjiBrutto>74500.00</rcw:cenaTransakcjiBrutto>
<rcw:podstawaPrawna xlink:type="simple" xlink:href="RCN_DK_6820"/>
<rcw:nieruchomosc xlink:type="simple" xlink:href="RCN_N_8872"/>
<rcw:nieruchomosc xlink:type="simple" xlink:href="RCN_N_8873"/>
</rcw:RCN_Transakcja></gml:featureMember>

<gml:featureMember>
<rcw:RCN_Dokument gml:id="RCN_DK_6820">
<rcw:oznaczenieDokumentu>REP.&quot;A&quot; NR: 724/2026</rcw:oznaczenieDokumentu>
<rcw:dataSporzadzeniaDokumentu>2026-02-20</rcw:dataSporzadzeniaDokumentu>
<rcw:tworcaDokumentu>KAN.NOT. MONIKA  TĘCZA-WĄSIK</rcw:tworcaDokumentu>
</rcw:RCN_Dokument>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Nieruchomosc gml:id="RCN_N_8872">
<rcw:rodzajNieruchomosci>3</rcw:rodzajNieruchomosci>
<rcw:rodzajPrawaDoNieruchomosci>1</rcw:rodzajPrawaDoNieruchomosci>
<rcw:udzialWPrawieDoNieruchomosci>1/1</rcw:udzialWPrawieDoNieruchomosci>
<rcw:polePowierzchniNieruchomosciGruntowej uom="ha">0.0018</rcw:polePowierzchniNieruchomosciGruntowej>
<rcw:opis>na działce posadowiony parterowy murowany garaż w zabudowie szeregowej, kryty blachą, posiadający instalację elektryczną</rcw:opis>
<rcw:cenaNieruchomosciBrutto>0.00</rcw:cenaNieruchomosciBrutto>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_21006"/>
<rcw:budynek xlink:type="simple" xlink:href="RCN_BU_21007"/>
</rcw:RCN_Nieruchomosc>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_21006">
<rcw:idDzialki>186401_1.0012.3640/50</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_21006_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60432769000000E+0006 7.54883394000000E+0006</gml:pos>
<gml:pos>5.60432642000000E+0006 7.54883995000000E+0006</gml:pos>
<gml:pos>5.60432936000000E+0006 7.54884058000000E+0006</gml:pos>
<gml:pos>5.60433063000000E+0006 7.54883456000000E+0006</gml:pos>
<gml:pos>5.60432769000000E+0006 7.54883394000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0018</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>3</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Budynek gml:id="RCN_BU_21007">
<rcw:idBudynku>186401_1.0012.3400_BUD</rcw:idBudynku>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_21007_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60432936000000E+0006 7.54884058000000E+0006</gml:pos>
<gml:pos>5.60433063000000E+0006 7.54883456000000E+0006</gml:pos>
<gml:pos>5.60432769000000E+0006 7.54883394000000E+0006</gml:pos>
<gml:pos>5.60432642000000E+0006 7.54883995000000E+0006</gml:pos>
<gml:pos>5.60432936000000E+0006 7.54884058000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:rodzajBudynku>102</rcw:rodzajBudynku>
<rcw:dodatkoweInformacje>pow.zabudowy=18</rcw:dodatkoweInformacje>
</rcw:RCN_Budynek>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Nieruchomosc gml:id="RCN_N_8873">
<rcw:rodzajNieruchomosci>1</rcw:rodzajNieruchomosci>
<rcw:rodzajPrawaDoNieruchomosci>2</rcw:rodzajPrawaDoNieruchomosci>
<rcw:udzialWPrawieDoNieruchomosci>1/31</rcw:udzialWPrawieDoNieruchomosci>
<rcw:polePowierzchniNieruchomosciGruntowej uom="ha">0.0482</rcw:polePowierzchniNieruchomosciGruntowej>
<rcw:cenaNieruchomosciBrutto>0.00</rcw:cenaNieruchomosciBrutto>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_21008"/>
</rcw:RCN_Nieruchomosc>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_21008">
<rcw:idDzialki>186401_1.0012.3640/4</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_21008_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60437279000000E+0006 7.54884977000000E+0006</gml:pos>
<gml:pos>5.60437489000000E+0006 7.54883872000000E+0006</gml:pos>
<gml:pos>5.60428148000000E+0006 7.54881911000000E+0006</gml:pos>
<gml:pos>5.60428037000000E+0006 7.54882392000000E+0006</gml:pos>
<gml:pos>5.60428367000000E+0006 7.54882462000000E+0006</gml:pos>
<gml:pos>5.60428660000000E+0006 7.54882523000000E+0006</gml:pos>
<gml:pos>5.60428954000000E+0006 7.54882586000000E+0006</gml:pos>
<gml:pos>5.60429247000000E+0006 7.54882648000000E+0006</gml:pos>
<gml:pos>5.60429541000000E+0006 7.54882710000000E+0006</gml:pos>
<gml:pos>5.60429834000000E+0006 7.54882772000000E+0006</gml:pos>
<gml:pos>5.60430128000000E+0006 7.54882835000000E+0006</gml:pos>
<gml:pos>5.60430421000000E+0006 7.54882897000000E+0006</gml:pos>
<gml:pos>5.60430714000000E+0006 7.54882959000000E+0006</gml:pos>
<gml:pos>5.60431009000000E+0006 7.54883021000000E+0006</gml:pos>
<gml:pos>5.60431302000000E+0006 7.54883084000000E+0006</gml:pos>
<gml:pos>5.60431596000000E+0006 7.54883145000000E+0006</gml:pos>
<gml:pos>5.60431889000000E+0006 7.54883207000000E+0006</gml:pos>
<gml:pos>5.60432183000000E+0006 7.54883270000000E+0006</gml:pos>
<gml:pos>5.60432476000000E+0006 7.54883331000000E+0006</gml:pos>
<gml:pos>5.60432769000000E+0006 7.54883394000000E+0006</gml:pos>
<gml:pos>5.60433063000000E+0006 7.54883456000000E+0006</gml:pos>
<gml:pos>5.60433356000000E+0006 7.54883518000000E+0006</gml:pos>
<gml:pos>5.60433651000000E+0006 7.54883580000000E+0006</gml:pos>
<gml:pos>5.60433944000000E+0006 7.54883643000000E+0006</gml:pos>
<gml:pos>5.60434238000000E+0006 7.54883704000000E+0006</gml:pos>
<gml:pos>5.60434531000000E+0006 7.54883767000000E+0006</gml:pos>
<gml:pos>5.60434824000000E+0006 7.54883829000000E+0006</gml:pos>
<gml:pos>5.60435118000000E+0006 7.54883890000000E+0006</gml:pos>
<gml:pos>5.60435411000000E+0006 7.54883953000000E+0006</gml:pos>
<gml:pos>5.60435705000000E+0006 7.54884015000000E+0006</gml:pos>
<gml:pos>5.60436018000000E+0006 7.54884081000000E+0006</gml:pos>
<gml:pos>5.60436361000000E+0006 7.54884154000000E+0006</gml:pos>
<gml:pos>5.60436684000000E+0006 7.54884223000000E+0006</gml:pos>
<gml:pos>5.60436977000000E+0006 7.54884284000000E+0006</gml:pos>
<gml:pos>5.60437358000000E+0006 7.54884365000000E+0006</gml:pos>
<gml:pos>5.60437227000000E+0006 7.54884965000000E+0006</gml:pos>
<gml:pos>5.60437279000000E+0006 7.54884977000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0482</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>3</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>


<gml:featureMember>
<rcw:RCN_Transakcja gml:id="RCN_T_6819">
<rcw:IdRCN>
<rcw:RCN_IdentyfikatorIIP>
<rcw:przestrzenNazw>PL.PZGiK.209</rcw:przestrzenNazw>
<rcw:lokalnyId>DCE42D66-A0E4-451A-B81C-1CB348DFF08D</rcw:lokalnyId>
</rcw:RCN_IdentyfikatorIIP>
</rcw:IdRCN>
<rcw:oznaczenieTransakcji>RCN_T_6819</rcw:oznaczenieTransakcji>
<rcw:rodzajTransakcji>1</rcw:rodzajTransakcji>
<rcw:stronaSprzedajaca>3</rcw:stronaSprzedajaca>
<rcw:stronaKupujaca>3</rcw:stronaKupujaca>
<rcw:cenaTransakcjiBrutto>447050.00</rcw:cenaTransakcjiBrutto>
<rcw:podstawaPrawna xlink:type="simple" xlink:href="RCN_DK_6819"/>
<rcw:nieruchomosc xlink:type="simple" xlink:href="RCN_N_8869"/>
<rcw:nieruchomosc xlink:type="simple" xlink:href="RCN_N_8870"/>
<rcw:nieruchomosc xlink:type="simple" xlink:href="RCN_N_8871"/>
</rcw:RCN_Transakcja></gml:featureMember>

<gml:featureMember>
<rcw:RCN_Dokument gml:id="RCN_DK_6819">
<rcw:oznaczenieDokumentu>REP.&quot;A&quot; NR: 684/2026</rcw:oznaczenieDokumentu>
<rcw:dataSporzadzeniaDokumentu>2026-02-19</rcw:dataSporzadzeniaDokumentu>
<rcw:tworcaDokumentu>KAN.NOT. MONIKA  TĘCZA-WĄSIK</rcw:tworcaDokumentu>
</rcw:RCN_Dokument>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Nieruchomosc gml:id="RCN_N_8869">
<rcw:rodzajNieruchomosci>4</rcw:rodzajNieruchomosci>
<rcw:rodzajPrawaDoNieruchomosci>3</rcw:rodzajPrawaDoNieruchomosci>
<rcw:udzialWPrawieDoNieruchomosci>1/1</rcw:udzialWPrawieDoNieruchomosci>
<rcw:polePowierzchniNieruchomosciGruntowej uom="ha">0.2605</rcw:polePowierzchniNieruchomosciGruntowej>
<rcw:opis>Udział lokalu w gruncie :6360/316022-lokal składa się z salonu z aneksem kuchennym, dwóch pokoi, łazienki korytarza pomieszczenia pomocnicznego oraz komórki lokatorskiej, piętro III</rcw:opis>
<rcw:cenaNieruchomosciBrutto>0.00</rcw:cenaNieruchomosciBrutto>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_21003"/>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_21000"/>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_20998"/>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_20999"/>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_21002"/>
<rcw:budynek xlink:type="simple" xlink:href="RCN_BU_21001"/>
<rcw:lokal xlink:type="simple" xlink:href="RCN_LO_20997"/>
</rcw:RCN_Nieruchomosc>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_21003">
<rcw:idDzialki>186401_1.0012.1998/4</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_21003_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60369148000000E+0006 7.54774964000000E+0006</gml:pos>
<gml:pos>5.60369917000000E+0006 7.54775769000000E+0006</gml:pos>
<gml:pos>5.60371652000000E+0006 7.54775389000000E+0006</gml:pos>
<gml:pos>5.60371578000000E+0006 7.54774302000000E+0006</gml:pos>
<gml:pos>5.60369092000000E+0006 7.54774102000000E+0006</gml:pos>
<gml:pos>5.60369148000000E+0006 7.54774964000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0326</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>3</rcw:sposobUzytkowania>
<rcw:adresDzialki>
<rcw:RCN_Adres gml:id="RCN_AD_10812">
<rcw:miejscowosc>TARNOBRZEG</rcw:miejscowosc>
<rcw:ulica>TARGOWA</rcw:ulica>
<rcw:numerPorzadkowy>13</rcw:numerPorzadkowy>
</rcw:RCN_Adres>
</rcw:adresDzialki>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_21000">
<rcw:idDzialki>186401_1.0012.2000</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_21000_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60369092000000E+0006 7.54774102000000E+0006</gml:pos>
<gml:pos>5.60371578000000E+0006 7.54774302000000E+0006</gml:pos>
<gml:pos>5.60371360000000E+0006 7.54771384000000E+0006</gml:pos>
<gml:pos>5.60368906000000E+0006 7.54771252000000E+0006</gml:pos>
<gml:pos>5.60369092000000E+0006 7.54774102000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0709</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>3</rcw:sposobUzytkowania>
<rcw:adresDzialki>
<rcw:RCN_Adres gml:id="RCN_AD_10809">
<rcw:miejscowosc>TARNOBRZEG</rcw:miejscowosc>
<rcw:ulica>TARGOWA</rcw:ulica>
<rcw:numerPorzadkowy>13</rcw:numerPorzadkowy>
</rcw:RCN_Adres>
</rcw:adresDzialki>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_20998">
<rcw:idDzialki>186401_1.0012.2002/10</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_20998_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60375150000000E+0006 7.54769067000000E+0006</gml:pos>
<gml:pos>5.60375383000000E+0006 7.54769057000000E+0006</gml:pos>
<gml:pos>5.60375367000000E+0006 7.54768669000000E+0006</gml:pos>
<gml:pos>5.60375132000000E+0006 7.54768683000000E+0006</gml:pos>
<gml:pos>5.60375150000000E+0006 7.54769067000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0009</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>3</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_20999">
<rcw:idDzialki>186401_1.0012.2002/12</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_20999_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60371652000000E+0006 7.54775389000000E+0006</gml:pos>
<gml:pos>5.60371663000000E+0006 7.54775541000000E+0006</gml:pos>
<gml:pos>5.60373348000000E+0006 7.54775172000000E+0006</gml:pos>
<gml:pos>5.60373299000000E+0006 7.54774953000000E+0006</gml:pos>
<gml:pos>5.60373125000000E+0006 7.54774193000000E+0006</gml:pos>
<gml:pos>5.60372870000000E+0006 7.54774249000000E+0006</gml:pos>
<gml:pos>5.60371924000000E+0006 7.54769931000000E+0006</gml:pos>
<gml:pos>5.60372437000000E+0006 7.54769819000000E+0006</gml:pos>
<gml:pos>5.60372944000000E+0006 7.54769709000000E+0006</gml:pos>
<gml:pos>5.60373599000000E+0006 7.54769566000000E+0006</gml:pos>
<gml:pos>5.60373538000000E+0006 7.54768463000000E+0006</gml:pos>
<gml:pos>5.60371467000000E+0006 7.54768579000000E+0006</gml:pos>
<gml:pos>5.60371539000000E+0006 7.54769141000000E+0006</gml:pos>
<gml:pos>5.60371529000000E+0006 7.54769264000000E+0006</gml:pos>
<gml:pos>5.60371481000000E+0006 7.54769410000000E+0006</gml:pos>
<gml:pos>5.60371422000000E+0006 7.54769636000000E+0006</gml:pos>
<gml:pos>5.60371410000000E+0006 7.54769831000000E+0006</gml:pos>
<gml:pos>5.60371426000000E+0006 7.54769984000000E+0006</gml:pos>
<gml:pos>5.60372220000000E+0006 7.54773626000000E+0006</gml:pos>
<gml:pos>5.60372223000000E+0006 7.54773928000000E+0006</gml:pos>
<gml:pos>5.60372252000000E+0006 7.54774113000000E+0006</gml:pos>
<gml:pos>5.60372318000000E+0006 7.54774307000000E+0006</gml:pos>
<gml:pos>5.60372396000000E+0006 7.54774450000000E+0006</gml:pos>
<gml:pos>5.60372523000000E+0006 7.54774610000000E+0006</gml:pos>
<gml:pos>5.60372702000000E+0006 7.54774762000000E+0006</gml:pos>
<gml:pos>5.60372860000000E+0006 7.54774852000000E+0006</gml:pos>
<gml:pos>5.60373014000000E+0006 7.54774909000000E+0006</gml:pos>
<gml:pos>5.60373052000000E+0006 7.54775083000000E+0006</gml:pos>
<gml:pos>5.60371652000000E+0006 7.54775389000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0564</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>3</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_21002">
<rcw:idDzialki>186401_1.0012.2002/8</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_21002_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60368894000000E+0006 7.54771084000000E+0006</gml:pos>
<gml:pos>5.60368906000000E+0006 7.54771252000000E+0006</gml:pos>
<gml:pos>5.60371360000000E+0006 7.54771384000000E+0006</gml:pos>
<gml:pos>5.60371578000000E+0006 7.54774302000000E+0006</gml:pos>
<gml:pos>5.60371652000000E+0006 7.54775389000000E+0006</gml:pos>
<gml:pos>5.60373052000000E+0006 7.54775083000000E+0006</gml:pos>
<gml:pos>5.60373014000000E+0006 7.54774909000000E+0006</gml:pos>
<gml:pos>5.60372860000000E+0006 7.54774852000000E+0006</gml:pos>
<gml:pos>5.60372702000000E+0006 7.54774762000000E+0006</gml:pos>
<gml:pos>5.60372523000000E+0006 7.54774610000000E+0006</gml:pos>
<gml:pos>5.60372396000000E+0006 7.54774450000000E+0006</gml:pos>
<gml:pos>5.60372318000000E+0006 7.54774307000000E+0006</gml:pos>
<gml:pos>5.60372252000000E+0006 7.54774113000000E+0006</gml:pos>
<gml:pos>5.60372223000000E+0006 7.54773928000000E+0006</gml:pos>
<gml:pos>5.60372220000000E+0006 7.54773626000000E+0006</gml:pos>
<gml:pos>5.60371426000000E+0006 7.54769984000000E+0006</gml:pos>
<gml:pos>5.60371410000000E+0006 7.54769831000000E+0006</gml:pos>
<gml:pos>5.60371422000000E+0006 7.54769636000000E+0006</gml:pos>
<gml:pos>5.60371481000000E+0006 7.54769410000000E+0006</gml:pos>
<gml:pos>5.60371529000000E+0006 7.54769264000000E+0006</gml:pos>
<gml:pos>5.60371539000000E+0006 7.54769141000000E+0006</gml:pos>
<gml:pos>5.60371467000000E+0006 7.54768579000000E+0006</gml:pos>
<gml:pos>5.60368706000000E+0006 7.54768733000000E+0006</gml:pos>
<gml:pos>5.60368894000000E+0006 7.54771084000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0997</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>3</rcw:sposobUzytkowania>
<rcw:adresDzialki>
<rcw:RCN_Adres gml:id="RCN_AD_10811">
<rcw:miejscowosc>TARNOBRZEG</rcw:miejscowosc>
<rcw:ulica>TARGOWA</rcw:ulica>
<rcw:numerPorzadkowy>13</rcw:numerPorzadkowy>
</rcw:RCN_Adres>
</rcw:adresDzialki>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Budynek gml:id="RCN_BU_21001">
<rcw:idBudynku>186401_1.0012.1628_BUD</rcw:idBudynku>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_21001_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60369423000000E+0006 7.54769302000000E+0006</gml:pos>
<gml:pos>5.60370587000000E+0006 7.54774646000000E+0006</gml:pos>
<gml:pos>5.60370811000000E+0006 7.54774599000000E+0006</gml:pos>
<gml:pos>5.60371313000000E+0006 7.54774492000000E+0006</gml:pos>
<gml:pos>5.60371865000000E+0006 7.54774374000000E+0006</gml:pos>
<gml:pos>5.60371735000000E+0006 7.54773778000000E+0006</gml:pos>
<gml:pos>5.60371599000000E+0006 7.54773150000000E+0006</gml:pos>
<gml:pos>5.60371350000000E+0006 7.54772012000000E+0006</gml:pos>
<gml:pos>5.60371215000000E+0006 7.54771393000000E+0006</gml:pos>
<gml:pos>5.60370965000000E+0006 7.54770243000000E+0006</gml:pos>
<gml:pos>5.60370830000000E+0006 7.54769624000000E+0006</gml:pos>
<gml:pos>5.60370699000000E+0006 7.54769024000000E+0006</gml:pos>
<gml:pos>5.60369423000000E+0006 7.54769302000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:rodzajBudynku>110</rcw:rodzajBudynku>
<rcw:dodatkoweInformacje>pow.zabudowy=715</rcw:dodatkoweInformacje>
<rcw:adresBudynku>
<rcw:RCN_Adres gml:id="RCN_AD_10810">
<rcw:miejscowosc>TARNOBRZEG</rcw:miejscowosc>
<rcw:ulica>TARGOWA</rcw:ulica>
<rcw:numerPorzadkowy>13</rcw:numerPorzadkowy>
</rcw:RCN_Adres>
</rcw:adresBudynku>
</rcw:RCN_Budynek>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Lokal gml:id="RCN_LO_20997">
<rcw:idLokalu>186401_1.0012.1628_BUD.25_LOK</rcw:idLokalu>
<rcw:georeferencja>
<gml:Point gml:id="Lok_G_20997" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:pos>5.60370644000000E+0006 7.54771835000000E+0006</gml:pos>
</gml:Point>
</rcw:georeferencja>
<rcw:funkcjaLokalu>1</rcw:funkcjaLokalu>
<rcw:liczbaIzb>5</rcw:liczbaIzb>
<rcw:nrKondygnacji>4</rcw:nrKondygnacji>
<rcw:powUzytkowaLokalu uom="m2">61.54</rcw:powUzytkowaLokalu>
<rcw:powUzytkowaPomieszczenPrzynal uom="m2">2.06</rcw:powUzytkowaPomieszczenPrzynal>
<rcw:dodatkoweInformacje>nr adr.lok.:25</rcw:dodatkoweInformacje>
<rcw:adresBudynkuZLokalem>
<rcw:RCN_Adres gml:id="RCN_AD_10808">
<rcw:miejscowosc>TARNOBRZEG</rcw:miejscowosc>
<rcw:ulica>TARGOWA</rcw:ulica>
<rcw:numerPorzadkowy>13</rcw:numerPorzadkowy>
</rcw:RCN_Adres>
</rcw:adresBudynkuZLokalem>
</rcw:RCN_Lokal>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Nieruchomosc gml:id="RCN_N_8870">
<rcw:rodzajNieruchomosci>1</rcw:rodzajNieruchomosci>
<rcw:rodzajPrawaDoNieruchomosci>1</rcw:rodzajPrawaDoNieruchomosci>
<rcw:udzialWPrawieDoNieruchomosci>1/120</rcw:udzialWPrawieDoNieruchomosci>
<rcw:polePowierzchniNieruchomosciGruntowej uom="ha">0.0180</rcw:polePowierzchniNieruchomosciGruntowej>
<rcw:cenaNieruchomosciBrutto>0.00</rcw:cenaNieruchomosciBrutto>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_21004"/>
</rcw:RCN_Nieruchomosc>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_21004">
<rcw:idDzialki>186401_1.0012.1998/5</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_21004_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60370393000000E+0006 7.54777490000000E+0006</gml:pos>
<gml:pos>5.60371387000000E+0006 7.54777609000000E+0006</gml:pos>
<gml:pos>5.60370968000000E+0006 7.54775693000000E+0006</gml:pos>
<gml:pos>5.60371663000000E+0006 7.54775541000000E+0006</gml:pos>
<gml:pos>5.60371652000000E+0006 7.54775389000000E+0006</gml:pos>
<gml:pos>5.60369917000000E+0006 7.54775769000000E+0006</gml:pos>
<gml:pos>5.60370299000000E+0006 7.54776169000000E+0006</gml:pos>
<gml:pos>5.60370393000000E+0006 7.54777490000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0180</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>3</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Nieruchomosc gml:id="RCN_N_8871">
<rcw:rodzajNieruchomosci>1</rcw:rodzajNieruchomosci>
<rcw:rodzajPrawaDoNieruchomosci>1</rcw:rodzajPrawaDoNieruchomosci>
<rcw:udzialWPrawieDoNieruchomosci>1/17</rcw:udzialWPrawieDoNieruchomosci>
<rcw:polePowierzchniNieruchomosciGruntowej uom="ha">0.0232</rcw:polePowierzchniNieruchomosciGruntowej>
<rcw:opis>lokal składa się z salonu z aneksem kuchennym, dwóch pokoi, łazienki korytarza pomieszczenia pomocnicznego oraz komórki lokatorskiej, piętro III</rcw:opis>
<rcw:cenaNieruchomosciBrutto>0.00</rcw:cenaNieruchomosciBrutto>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_21005"/>
</rcw:RCN_Nieruchomosc>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_21005">
<rcw:idDzialki>186401_1.0012.2002/14</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_21005_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60373382000000E+0006 7.54774137000000E+0006</gml:pos>
<gml:pos>5.60372437000000E+0006 7.54769819000000E+0006</gml:pos>
<gml:pos>5.60371924000000E+0006 7.54769931000000E+0006</gml:pos>
<gml:pos>5.60372870000000E+0006 7.54774249000000E+0006</gml:pos>
<gml:pos>5.60373125000000E+0006 7.54774193000000E+0006</gml:pos>
<gml:pos>5.60373382000000E+0006 7.54774137000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0232</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>3</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>


<gml:featureMember>
<rcw:RCN_Transakcja gml:id="RCN_T_6818">
<rcw:IdRCN>
<rcw:RCN_IdentyfikatorIIP>
<rcw:przestrzenNazw>PL.PZGiK.209</rcw:przestrzenNazw>
<rcw:lokalnyId>401E2A69-AC8F-43BC-ADB1-3F8DFDF87634</rcw:lokalnyId>
</rcw:RCN_IdentyfikatorIIP>
</rcw:IdRCN>
<rcw:oznaczenieTransakcji>RCN_T_6818</rcw:oznaczenieTransakcji>
<rcw:rodzajTransakcji>1</rcw:rodzajTransakcji>
<rcw:stronaSprzedajaca>3</rcw:stronaSprzedajaca>
<rcw:stronaKupujaca>3</rcw:stronaKupujaca>
<rcw:cenaTransakcjiBrutto>280000.00</rcw:cenaTransakcjiBrutto>
<rcw:podstawaPrawna xlink:type="simple" xlink:href="RCN_DK_6818"/>
<rcw:nieruchomosc xlink:type="simple" xlink:href="RCN_N_8868"/>
</rcw:RCN_Transakcja></gml:featureMember>

<gml:featureMember>
<rcw:RCN_Dokument gml:id="RCN_DK_6818">
<rcw:oznaczenieDokumentu>REP.&quot;A&quot; NR: 1101/2026</rcw:oznaczenieDokumentu>
<rcw:dataSporzadzeniaDokumentu>2026-02-24</rcw:dataSporzadzeniaDokumentu>
<rcw:tworcaDokumentu>Kancelaria Notarialna Krystyna Wisz</rcw:tworcaDokumentu>
</rcw:RCN_Dokument>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Nieruchomosc gml:id="RCN_N_8868">
<rcw:rodzajNieruchomosci>4</rcw:rodzajNieruchomosci>
<rcw:rodzajPrawaDoNieruchomosci>3</rcw:rodzajPrawaDoNieruchomosci>
<rcw:udzialWPrawieDoNieruchomosci>1/1</rcw:udzialWPrawieDoNieruchomosci>
<rcw:polePowierzchniNieruchomosciGruntowej uom="ha">0.3221</rcw:polePowierzchniNieruchomosciGruntowej>
<rcw:opis>Udział lokalu w gruncie :5168/398589- lokal składa się z dwóch pokoi. kuchni, łazienki z wc oraz przedpokoju; posiada balkon i przynależną piwnicę, </rcw:opis>
<rcw:cenaNieruchomosciBrutto>0.00</rcw:cenaNieruchomosciBrutto>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_20995"/>
<rcw:budynek xlink:type="simple" xlink:href="RCN_BU_20996"/>
<rcw:lokal xlink:type="simple" xlink:href="RCN_LO_20994"/>
</rcw:RCN_Nieruchomosc>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_20995">
<rcw:idDzialki>186401_1.0012.1237/136</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_20995_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60464204000000E+0006 7.54850159000000E+0006</gml:pos>
<gml:pos>5.60464163000000E+0006 7.54850351000000E+0006</gml:pos>
<gml:pos>5.60464074000000E+0006 7.54850745000000E+0006</gml:pos>
<gml:pos>5.60463221000000E+0006 7.54850550000000E+0006</gml:pos>
<gml:pos>5.60462972000000E+0006 7.54850493000000E+0006</gml:pos>
<gml:pos>5.60462754000000E+0006 7.54851496000000E+0006</gml:pos>
<gml:pos>5.60463649000000E+0006 7.54851716000000E+0006</gml:pos>
<gml:pos>5.60463676000000E+0006 7.54851555000000E+0006</gml:pos>
<gml:pos>5.60464552000000E+0006 7.54851759000000E+0006</gml:pos>
<gml:pos>5.60472205000000E+0006 7.54853527000000E+0006</gml:pos>
<gml:pos>5.60473834000000E+0006 7.54853870000000E+0006</gml:pos>
<gml:pos>5.60474308000000E+0006 7.54850948000000E+0006</gml:pos>
<gml:pos>5.60463426000000E+0006 7.54848402000000E+0006</gml:pos>
<gml:pos>5.60463289000000E+0006 7.54849037000000E+0006</gml:pos>
<gml:pos>5.60463551000000E+0006 7.54849098000000E+0006</gml:pos>
<gml:pos>5.60464402000000E+0006 7.54849300000000E+0006</gml:pos>
<gml:pos>5.60464344000000E+0006 7.54849561000000E+0006</gml:pos>
<gml:pos>5.60464204000000E+0006 7.54850159000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.3221</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>3</rcw:sposobUzytkowania>
<rcw:adresDzialki>
<rcw:RCN_Adres gml:id="RCN_AD_10807">
<rcw:miejscowosc></rcw:miejscowosc>
<rcw:ulica>DĄBROWSKIEJ</rcw:ulica>
<rcw:numerPorzadkowy>27</rcw:numerPorzadkowy>
</rcw:RCN_Adres>
</rcw:adresDzialki>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Budynek gml:id="RCN_BU_20996">
<rcw:idBudynku>186401_1.0012.404_BUD</rcw:idBudynku>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_20996_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60473223000000E+0006 7.54852789000000E+0006</gml:pos>
<gml:pos>5.60473467000000E+0006 7.54851753000000E+0006</gml:pos>
<gml:pos>5.60469565000000E+0006 7.54850857000000E+0006</gml:pos>
<gml:pos>5.60469603000000E+0006 7.54850690000000E+0006</gml:pos>
<gml:pos>5.60466970000000E+0006 7.54850093000000E+0006</gml:pos>
<gml:pos>5.60467025000000E+0006 7.54849920000000E+0006</gml:pos>
<gml:pos>5.60464402000000E+0006 7.54849300000000E+0006</gml:pos>
<gml:pos>5.60464344000000E+0006 7.54849561000000E+0006</gml:pos>
<gml:pos>5.60464204000000E+0006 7.54850159000000E+0006</gml:pos>
<gml:pos>5.60464163000000E+0006 7.54850351000000E+0006</gml:pos>
<gml:pos>5.60465941000000E+0006 7.54850757000000E+0006</gml:pos>
<gml:pos>5.60466771000000E+0006 7.54850947000000E+0006</gml:pos>
<gml:pos>5.60466732000000E+0006 7.54851119000000E+0006</gml:pos>
<gml:pos>5.60469346000000E+0006 7.54851729000000E+0006</gml:pos>
<gml:pos>5.60469313000000E+0006 7.54851897000000E+0006</gml:pos>
<gml:pos>5.60470035000000E+0006 7.54852062000000E+0006</gml:pos>
<gml:pos>5.60472602000000E+0006 7.54852651000000E+0006</gml:pos>
<gml:pos>5.60473223000000E+0006 7.54852789000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:rodzajBudynku>110</rcw:rodzajBudynku>
<rcw:dodatkoweInformacje>pow.zabudowy=1001</rcw:dodatkoweInformacje>
</rcw:RCN_Budynek>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Lokal gml:id="RCN_LO_20994">
<rcw:idLokalu>186401_1.0012.404_BUD.36_LOK</rcw:idLokalu>
<rcw:georeferencja>
<gml:Point gml:id="Lok_G_20994" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:pos>5.60468815000000E+0006 7.54851058000000E+0006</gml:pos>
</gml:Point>
</rcw:georeferencja>
<rcw:funkcjaLokalu>1</rcw:funkcjaLokalu>
<rcw:liczbaIzb>5</rcw:liczbaIzb>
<rcw:nrKondygnacji>3</rcw:nrKondygnacji>
<rcw:powUzytkowaLokalu uom="m2">48.00</rcw:powUzytkowaLokalu>
<rcw:powUzytkowaPomieszczenPrzynal uom="m2">3.68</rcw:powUzytkowaPomieszczenPrzynal>
<rcw:dodatkoweInformacje>nr adr.lok.:36</rcw:dodatkoweInformacje>
</rcw:RCN_Lokal>
</gml:featureMember>


<gml:featureMember>
<rcw:RCN_Transakcja gml:id="RCN_T_6816">
<rcw:IdRCN>
<rcw:RCN_IdentyfikatorIIP>
<rcw:przestrzenNazw>PL.PZGiK.209</rcw:przestrzenNazw>
<rcw:lokalnyId>A8C83518-AB21-4FF3-A0E2-72270661CA2A</rcw:lokalnyId>
</rcw:RCN_IdentyfikatorIIP>
</rcw:IdRCN>
<rcw:oznaczenieTransakcji>RCN_T_6816</rcw:oznaczenieTransakcji>
<rcw:rodzajTransakcji>1</rcw:rodzajTransakcji>
<rcw:stronaSprzedajaca>3</rcw:stronaSprzedajaca>
<rcw:stronaKupujaca>3</rcw:stronaKupujaca>
<rcw:cenaTransakcjiBrutto>32000.00</rcw:cenaTransakcjiBrutto>
<rcw:podstawaPrawna xlink:type="simple" xlink:href="RCN_DK_6816"/>
<rcw:nieruchomosc xlink:type="simple" xlink:href="RCN_N_8866"/>
</rcw:RCN_Transakcja></gml:featureMember>

<gml:featureMember>
<rcw:RCN_Dokument gml:id="RCN_DK_6816">
<rcw:oznaczenieDokumentu>REP.A:884/2026</rcw:oznaczenieDokumentu>
<rcw:dataSporzadzeniaDokumentu>2026-02-13</rcw:dataSporzadzeniaDokumentu>
<rcw:tworcaDokumentu>Kancelaria Notarialna Krystyna Wisz</rcw:tworcaDokumentu>
</rcw:RCN_Dokument>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Nieruchomosc gml:id="RCN_N_8866">
<rcw:rodzajNieruchomosci>1</rcw:rodzajNieruchomosci>
<rcw:rodzajPrawaDoNieruchomosci>1</rcw:rodzajPrawaDoNieruchomosci>
<rcw:udzialWPrawieDoNieruchomosci>1/1</rcw:udzialWPrawieDoNieruchomosci>
<rcw:polePowierzchniNieruchomosciGruntowej uom="ha">1.2298</rcw:polePowierzchniNieruchomosciGruntowej>
<rcw:opis>Działki nie są objęte obowizującym MPZP oraz nie sa objete miejscowym planem rewitalizacji. </rcw:opis>
<rcw:cenaNieruchomosciBrutto>0.00</rcw:cenaNieruchomosciBrutto>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_20991"/>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_20992"/>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_20985"/>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_20990"/>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_20986"/>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_20987"/>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_20988"/>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_20989"/>
</rcw:RCN_Nieruchomosc>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_20991">
<rcw:idDzialki>186401_1.0007.1299</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_20991_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60865226000000E+0006 7.55175776000000E+0006</gml:pos>
<gml:pos>5.60862137000000E+0006 7.55177588000000E+0006</gml:pos>
<gml:pos>5.60859239000000E+0006 7.55179293000000E+0006</gml:pos>
<gml:pos>5.60856094000000E+0006 7.55181156000000E+0006</gml:pos>
<gml:pos>5.60852753000000E+0006 7.55183167000000E+0006</gml:pos>
<gml:pos>5.60850548000000E+0006 7.55184482000000E+0006</gml:pos>
<gml:pos>5.60849042000000E+0006 7.55185422000000E+0006</gml:pos>
<gml:pos>5.60846961000000E+0006 7.55186763000000E+0006</gml:pos>
<gml:pos>5.60845389000000E+0006 7.55187920000000E+0006</gml:pos>
<gml:pos>5.60843735000000E+0006 7.55189020000000E+0006</gml:pos>
<gml:pos>5.60842547000000E+0006 7.55189952000000E+0006</gml:pos>
<gml:pos>5.60841567000000E+0006 7.55190816000000E+0006</gml:pos>
<gml:pos>5.60842022000000E+0006 7.55191197000000E+0006</gml:pos>
<gml:pos>5.60843482000000E+0006 7.55190069000000E+0006</gml:pos>
<gml:pos>5.60845501000000E+0006 7.55188640000000E+0006</gml:pos>
<gml:pos>5.60847561000000E+0006 7.55187240000000E+0006</gml:pos>
<gml:pos>5.60851561000000E+0006 7.55184683000000E+0006</gml:pos>
<gml:pos>5.60853632000000E+0006 7.55183395000000E+0006</gml:pos>
<gml:pos>5.60856666000000E+0006 7.55181601000000E+0006</gml:pos>
<gml:pos>5.60860354000000E+0006 7.55179375000000E+0006</gml:pos>
<gml:pos>5.60864246000000E+0006 7.55177092000000E+0006</gml:pos>
<gml:pos>5.60867769000000E+0006 7.55174998000000E+0006</gml:pos>
<gml:pos>5.60870419000000E+0006 7.55173396000000E+0006</gml:pos>
<gml:pos>5.60873865000000E+0006 7.55171371000000E+0006</gml:pos>
<gml:pos>5.60875997000000E+0006 7.55170144000000E+0006</gml:pos>
<gml:pos>5.60878912000000E+0006 7.55168477000000E+0006</gml:pos>
<gml:pos>5.60882272000000E+0006 7.55166551000000E+0006</gml:pos>
<gml:pos>5.60885371000000E+0006 7.55164761000000E+0006</gml:pos>
<gml:pos>5.60888676000000E+0006 7.55162829000000E+0006</gml:pos>
<gml:pos>5.60891260000000E+0006 7.55161331000000E+0006</gml:pos>
<gml:pos>5.60894399000000E+0006 7.55159505000000E+0006</gml:pos>
<gml:pos>5.60893908000000E+0006 7.55159174000000E+0006</gml:pos>
<gml:pos>5.60891089000000E+0006 7.55160795000000E+0006</gml:pos>
<gml:pos>5.60888511000000E+0006 7.55162281000000E+0006</gml:pos>
<gml:pos>5.60885182000000E+0006 7.55164221000000E+0006</gml:pos>
<gml:pos>5.60882170000000E+0006 7.55165988000000E+0006</gml:pos>
<gml:pos>5.60878767000000E+0006 7.55167965000000E+0006</gml:pos>
<gml:pos>5.60875863000000E+0006 7.55169633000000E+0006</gml:pos>
<gml:pos>5.60872203000000E+0006 7.55171738000000E+0006</gml:pos>
<gml:pos>5.60868749000000E+0006 7.55173738000000E+0006</gml:pos>
<gml:pos>5.60865226000000E+0006 7.55175776000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.3689</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>1</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_20992">
<rcw:idDzialki>186401_1.0007.1428</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_20992_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60903557000000E+0006 7.55239472000000E+0006</gml:pos>
<gml:pos>5.60902977000000E+0006 7.55239065000000E+0006</gml:pos>
<gml:pos>5.60899224000000E+0006 7.55246055000000E+0006</gml:pos>
<gml:pos>5.60896961000000E+0006 7.55250353000000E+0006</gml:pos>
<gml:pos>5.60896797000000E+0006 7.55250660000000E+0006</gml:pos>
<gml:pos>5.60897360000000E+0006 7.55251196000000E+0006</gml:pos>
<gml:pos>5.60897517000000E+0006 7.55250900000000E+0006</gml:pos>
<gml:pos>5.60899899000000E+0006 7.55246402000000E+0006</gml:pos>
<gml:pos>5.60903557000000E+0006 7.55239472000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0977</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>1</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_20985">
<rcw:idDzialki>186401_1.0007.202</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_20985_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.61109950000000E+0006 7.55108595000000E+0006</gml:pos>
<gml:pos>5.61109408000000E+0006 7.55108288000000E+0006</gml:pos>
<gml:pos>5.61106253000000E+0006 7.55111717000000E+0006</gml:pos>
<gml:pos>5.61103170000000E+0006 7.55115042000000E+0006</gml:pos>
<gml:pos>5.61099684000000E+0006 7.55118800000000E+0006</gml:pos>
<gml:pos>5.61096786000000E+0006 7.55121940000000E+0006</gml:pos>
<gml:pos>5.61094844000000E+0006 7.55124047000000E+0006</gml:pos>
<gml:pos>5.61095440000000E+0006 7.55124416000000E+0006</gml:pos>
<gml:pos>5.61097275000000E+0006 7.55122441000000E+0006</gml:pos>
<gml:pos>5.61100268000000E+0006 7.55119165000000E+0006</gml:pos>
<gml:pos>5.61103700000000E+0006 7.55115429000000E+0006</gml:pos>
<gml:pos>5.61106977000000E+0006 7.55111865000000E+0006</gml:pos>
<gml:pos>5.61109950000000E+0006 7.55108595000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.1415</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>1</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_20990">
<rcw:idDzialki>186401_1.0007.341</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_20990_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.61115780000000E+0006 7.55151037000000E+0006</gml:pos>
<gml:pos>5.61115388000000E+0006 7.55150322000000E+0006</gml:pos>
<gml:pos>5.61114942000000E+0006 7.55149110000000E+0006</gml:pos>
<gml:pos>5.61113886000000E+0006 7.55150042000000E+0006</gml:pos>
<gml:pos>5.61113177000000E+0006 7.55150711000000E+0006</gml:pos>
<gml:pos>5.61111119000000E+0006 7.55152704000000E+0006</gml:pos>
<gml:pos>5.61108953000000E+0006 7.55154896000000E+0006</gml:pos>
<gml:pos>5.61107092000000E+0006 7.55156844000000E+0006</gml:pos>
<gml:pos>5.61104141000000E+0006 7.55160067000000E+0006</gml:pos>
<gml:pos>5.61104282000000E+0006 7.55160206000000E+0006</gml:pos>
<gml:pos>5.61105027000000E+0006 7.55160937000000E+0006</gml:pos>
<gml:pos>5.61105719000000E+0006 7.55161565000000E+0006</gml:pos>
<gml:pos>5.61109869000000E+0006 7.55157042000000E+0006</gml:pos>
<gml:pos>5.61113004000000E+0006 7.55153795000000E+0006</gml:pos>
<gml:pos>5.61115780000000E+0006 7.55151037000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.3182</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>1</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_20986">
<rcw:idDzialki>186401_1.0007.403</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_20986_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.61115101000000E+0006 7.55162405000000E+0006</gml:pos>
<gml:pos>5.61112590000000E+0006 7.55165739000000E+0006</gml:pos>
<gml:pos>5.61110350000000E+0006 7.55168744000000E+0006</gml:pos>
<gml:pos>5.61108604000000E+0006 7.55171131000000E+0006</gml:pos>
<gml:pos>5.61106741000000E+0006 7.55173840000000E+0006</gml:pos>
<gml:pos>5.61104798000000E+0006 7.55176766000000E+0006</gml:pos>
<gml:pos>5.61103578000000E+0006 7.55178661000000E+0006</gml:pos>
<gml:pos>5.61102485000000E+0006 7.55180506000000E+0006</gml:pos>
<gml:pos>5.61102919000000E+0006 7.55180723000000E+0006</gml:pos>
<gml:pos>5.61103982000000E+0006 7.55179113000000E+0006</gml:pos>
<gml:pos>5.61105445000000E+0006 7.55176869000000E+0006</gml:pos>
<gml:pos>5.61107317000000E+0006 7.55174083000000E+0006</gml:pos>
<gml:pos>5.61109359000000E+0006 7.55171144000000E+0006</gml:pos>
<gml:pos>5.61110917000000E+0006 7.55169023000000E+0006</gml:pos>
<gml:pos>5.61113116000000E+0006 7.55166050000000E+0006</gml:pos>
<gml:pos>5.61115571000000E+0006 7.55162681000000E+0006</gml:pos>
<gml:pos>5.61115101000000E+0006 7.55162405000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.1316</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>1</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_20987">
<rcw:idDzialki>186401_1.0007.521</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_20987_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.61057972000000E+0006 7.55195033000000E+0006</gml:pos>
<gml:pos>5.61057974000000E+0006 7.55194830000000E+0006</gml:pos>
<gml:pos>5.61057937000000E+0006 7.55194231000000E+0006</gml:pos>
<gml:pos>5.61053346000000E+0006 7.55192383000000E+0006</gml:pos>
<gml:pos>5.61049508000000E+0006 7.55190753000000E+0006</gml:pos>
<gml:pos>5.61048974000000E+0006 7.55190516000000E+0006</gml:pos>
<gml:pos>5.61048826000000E+0006 7.55191476000000E+0006</gml:pos>
<gml:pos>5.61049271000000E+0006 7.55191661000000E+0006</gml:pos>
<gml:pos>5.61053321000000E+0006 7.55193256000000E+0006</gml:pos>
<gml:pos>5.61057972000000E+0006 7.55195033000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0809</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>1</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_20988">
<rcw:idDzialki>186401_1.0007.522</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_20988_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.61044115000000E+0006 7.55188453000000E+0006</gml:pos>
<gml:pos>5.61044005000000E+0006 7.55189168000000E+0006</gml:pos>
<gml:pos>5.61043922000000E+0006 7.55189645000000E+0006</gml:pos>
<gml:pos>5.61047092000000E+0006 7.55190859000000E+0006</gml:pos>
<gml:pos>5.61048498000000E+0006 7.55191361000000E+0006</gml:pos>
<gml:pos>5.61048650000000E+0006 7.55190398000000E+0006</gml:pos>
<gml:pos>5.61047237000000E+0006 7.55189775000000E+0006</gml:pos>
<gml:pos>5.61044115000000E+0006 7.55188453000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0532</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>1</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>
<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_20989">
<rcw:idDzialki>186401_1.0007.524</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_20989_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.61058007000000E+0006 7.55195843000000E+0006</gml:pos>
<gml:pos>5.61053157000000E+0006 7.55194135000000E+0006</gml:pos>
<gml:pos>5.61050429000000E+0006 7.55193126000000E+0006</gml:pos>
<gml:pos>5.61050261000000E+0006 7.55193589000000E+0006</gml:pos>
<gml:pos>5.61053388000000E+0006 7.55194732000000E+0006</gml:pos>
<gml:pos>5.61058027000000E+0006 7.55196285000000E+0006</gml:pos>
<gml:pos>5.61058015000000E+0006 7.55195927000000E+0006</gml:pos>
<gml:pos>5.61058007000000E+0006 7.55195843000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0378</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>1</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>


<gml:featureMember>
<rcw:RCN_Transakcja gml:id="RCN_T_6814">
<rcw:IdRCN>
<rcw:RCN_IdentyfikatorIIP>
<rcw:przestrzenNazw>PL.PZGiK.209</rcw:przestrzenNazw>
<rcw:lokalnyId>18D85525-CFA9-4164-80E4-064507BAF044</rcw:lokalnyId>
</rcw:RCN_IdentyfikatorIIP>
</rcw:IdRCN>
<rcw:oznaczenieTransakcji>RCN_T_6814</rcw:oznaczenieTransakcji>
<rcw:rodzajTransakcji>2</rcw:rodzajTransakcji>
<rcw:stronaSprzedajaca>2</rcw:stronaSprzedajaca>
<rcw:stronaKupujaca>3</rcw:stronaKupujaca>
<rcw:cenaTransakcjiBrutto>36900.00</rcw:cenaTransakcjiBrutto>
<rcw:kwotaPodatkuVAT>6900.00</rcw:kwotaPodatkuVAT>
<rcw:podstawaPrawna xlink:type="simple" xlink:href="RCN_DK_6814"/>
<rcw:nieruchomosc xlink:type="simple" xlink:href="RCN_N_8862"/>
</rcw:RCN_Transakcja></gml:featureMember>

<gml:featureMember>
<rcw:RCN_Dokument gml:id="RCN_DK_6814">
<rcw:oznaczenieDokumentu>REP.&quot;A&quot; NR: 967/2026</rcw:oznaczenieDokumentu>
<rcw:dataSporzadzeniaDokumentu>2026-02-24</rcw:dataSporzadzeniaDokumentu>
<rcw:tworcaDokumentu>KAN.NOT.SŁAWOMIR POSŁUSZNY-NOTARIUSZ</rcw:tworcaDokumentu>
</rcw:RCN_Dokument>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Nieruchomosc gml:id="RCN_N_8862">
<rcw:rodzajNieruchomosci>1</rcw:rodzajNieruchomosci>
<rcw:rodzajPrawaDoNieruchomosci>1</rcw:rodzajPrawaDoNieruchomosci>
<rcw:udzialWPrawieDoNieruchomosci>1/1</rcw:udzialWPrawieDoNieruchomosci>
<rcw:polePowierzchniNieruchomosciGruntowej uom="ha">0.0044</rcw:polePowierzchniNieruchomosciGruntowej>
<rcw:opis>działka objęta obowiązującym MPZP osiedla Centrum i stanowi tereny zabudowy usługowej, działka położona w granicach obszaru zdegradowanego i obszaru rewitalizacji- nie zostało ustanowione prawo pierwokupu, nie jest objęta uproszczonym planem urządzenia lasu</rcw:opis>
<rcw:cenaNieruchomosciBrutto>0.00</rcw:cenaNieruchomosciBrutto>
<rcw:dzialka xlink:type="simple" xlink:href="RCN_DZ_20971"/>
</rcw:RCN_Nieruchomosc>
</gml:featureMember>

<gml:featureMember>
<rcw:RCN_Dzialka gml:id="RCN_DZ_20971">
<rcw:idDzialki>186401_1.0012.1322/5</rcw:idDzialki>
<rcw:geometria>
<gml:Polygon gml:id="DzBu_G_20971_0" srsName="urn:ogc:def:crs:EPSG::2178" srsDimension="2">
<gml:exterior>
<gml:LinearRing>
<gml:pos>5.60455952000000E+0006 7.54778863000000E+0006</gml:pos>
<gml:pos>5.60456148000000E+0006 7.54778315000000E+0006</gml:pos>
<gml:pos>5.60455302000000E+0006 7.54778014000000E+0006</gml:pos>
<gml:pos>5.60455157000000E+0006 7.54778375000000E+0006</gml:pos>
<gml:pos>5.60455303000000E+0006 7.54778458000000E+0006</gml:pos>
<gml:pos>5.60455663000000E+0006 7.54778698000000E+0006</gml:pos>
<gml:pos>5.60455952000000E+0006 7.54778863000000E+0006</gml:pos>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</rcw:geometria>
<rcw:polePowierzchniEwidencyjnej uom="ha">0.0044</rcw:polePowierzchniEwidencyjnej>
<rcw:sposobUzytkowania>5</rcw:sposobUzytkowania>
</rcw:RCN_Dzialka>
</gml:featureMember>


</gml:FeatureCollection>
